package com.example.lab1.repository;

import com.example.lab1.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

// @DataJpaTest поднимает встроенную БД (H2).
@DataJpaTest
class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    void savesAndFindsUserByUsername() {
        userRepository.save(new User("alice", "alice@mail.com", "hashed-pw"));

        assertThat(userRepository.findByUsername("alice"))
                .isPresent()
                .get()
                .extracting(User::getEmail)
                .isEqualTo("alice@mail.com");
    }

    @Test
    void existsByUsernameAndEmail_reflectStoredData() {
        userRepository.save(new User("bob", "bob@mail.com", "hashed-pw"));

        assertThat(userRepository.existsByUsername("bob")).isTrue();
        assertThat(userRepository.existsByEmail("bob@mail.com")).isTrue();
        assertThat(userRepository.existsByUsername("missing")).isFalse();
    }
}
