package com.example.lab1.service;

import com.example.lab1.model.User;
import com.example.lab1.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

// Юнит-тесты логики регистрации/авторизации с замоканным репозиторием.
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void register_savesUser_whenDataIsValid() {
        when(userRepository.existsByUsername("alice")).thenReturn(false);
        when(userRepository.existsByEmail("alice@mail.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        User saved = userService.register("alice", "alice@mail.com", "password1");

        assertThat(saved.getUsername()).isEqualTo("alice");
        assertThat(saved.getPassword()).isNotEqualTo("password1"); // должен быть хеш
        verify(userRepository).save(any(User.class));
    }

    @Test
    void register_failsOnDuplicateUsername() {
        when(userRepository.existsByUsername("alice")).thenReturn(true);

        assertThatThrownBy(() -> userService.register("alice", "alice@mail.com", "password1"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("логином");

        verify(userRepository, never()).save(any());
    }

    @Test
    void register_failsOnDuplicateEmail() {
        when(userRepository.existsByUsername("bob")).thenReturn(false);
        when(userRepository.existsByEmail("bob@mail.com")).thenReturn(true);

        assertThatThrownBy(() -> userService.register("bob", "bob@mail.com", "password1"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("почтой");
    }

    @Test
    void register_failsOnInvalidEmail() {
        assertThatThrownBy(() -> userService.register("bob", "not-an-email", "password1"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("почты");

        verify(userRepository, never()).save(any());
    }

    @Test
    void register_failsOnWeakPassword() {
        assertThatThrownBy(() -> userService.register("bob", "bob@mail.com", "12345"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Пароль");

        verify(userRepository, never()).save(any());
    }

    @Test
    void authenticate_returnsUser_whenPasswordMatches() {
        // Сохраним пользователя через register, чтобы получить корректный хеш.
        when(userRepository.existsByUsername("alice")).thenReturn(false);
        when(userRepository.existsByEmail("alice@mail.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));
        User registered = userService.register("alice", "alice@mail.com", "password1");

        when(userRepository.findByUsername("alice")).thenReturn(Optional.of(registered));

        Optional<User> result = userService.authenticate("alice", "password1");

        assertThat(result).isPresent();
        assertThat(result.get().getUsername()).isEqualTo("alice");
    }

    @Test
    void authenticate_returnsEmpty_whenPasswordWrong() {
        when(userRepository.existsByUsername("alice")).thenReturn(false);
        when(userRepository.existsByEmail("alice@mail.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));
        User registered = userService.register("alice", "alice@mail.com", "password1");

        when(userRepository.findByUsername("alice")).thenReturn(Optional.of(registered));

        assertThat(userService.authenticate("alice", "wrongPass1")).isEmpty();
    }
}
