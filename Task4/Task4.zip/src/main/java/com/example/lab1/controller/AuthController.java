package com.example.lab1.controller;

import com.example.lab1.model.User;
import com.example.lab1.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

// Маршруты страницы входа/регистрации.
@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // Показ формы. tab=login или tab=register управляет активной вкладкой.
    @GetMapping("/auth")
    public String authPage(@RequestParam(value = "tab", required = false, defaultValue = "login") String tab,
                           Model model) {
        model.addAttribute("tab", tab);
        return "auth";
    }

    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String email,
                           @RequestParam String password,
                           Model model) {
        try {
            userService.register(username, email, password);
            // Успех: переключаем на вкладку входа с сообщением.
            model.addAttribute("tab", "login");
            model.addAttribute("info", "Регистрация прошла успешно. Теперь войдите в аккаунт.");
            return "auth";
        } catch (IllegalArgumentException ex) {
            // Ошибка: возвращаем на форму с сообщением и сохранёнными значениями.
            model.addAttribute("tab", "register");
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("username", username);
            model.addAttribute("email", email);
            return "auth";
        }
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        Optional<User> user = userService.authenticate(username, password);
        if (user.isPresent()) {
            // Кладём имя в сессию — пользователь считается вошедшим.
            session.setAttribute("currentUser", user.get().getUsername());
            return "redirect:/";
        }
        model.addAttribute("tab", "login");
        model.addAttribute("error", "Неверный логин или пароль");
        model.addAttribute("username", username);
        return "auth";
    }
}
